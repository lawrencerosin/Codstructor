var box;
function SelectBox(item){
   if(box==item){
       box.style.border="none";
       box=undefined;
   }
   else{
        //Unselects the old box
        if(box!==undefined)
           box.style.border="none";
        box=item;
        item.style.border="5px solid white";
   }
}
function PlaceBox(){
  //Avoids the erro
  if(box!==undefined)
  code.appendChild(box.cloneNode(true));
  //box=undefined;
}