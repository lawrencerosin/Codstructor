
function Connect(file, callback){
    WebAssembly.instantiateStreaming(fetch("../WASM"+file), importObject).then(
       (obj)=>callback(),
    );
}